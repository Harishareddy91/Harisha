﻿var myApp = angular.module("myApp", ["ngRoute"]);

myApp.controller("myCtrl", function ($scope) {

});

myApp.config(["$routeProvider", function ($routeProvider) {
    $routeProvider.when("/", { templateUrl: "temps/home.html", controller: "HomeCtrl", title: "Home" })
                  .when("/products", { templateUrl: "temps/products.html", controller: "ProdCtrl", title: "Products" })
                  .when("/services", { templateUrl: "temps/services.html", controller: "ServicesCtrl", title: "Services" })
                  .when("/contactus", { templateUrl: "temps/contactus.html", controller: "ContactCtrl", title: "Contact Us" })
                  .otherwise("/home", { templateUrl: "temps/home.html" });
}]);

myApp.run(['$rootScope', function ($rootScope) {
    $rootScope.$on('$routeChangeSuccess', function (event, current, previous) {
        $rootScope.mytitle = current.$$route.title;
    });
}]);


myApp.controller("HomeCtrl", function ($scope) {

});

myApp.controller("ProdCtrl", function ($scope) {
    $scope.products = [{ prodName: "TV", price: "25000", vara: "2years" },
                       { prodName: "Mobile", price: "20000", vara: "1year" },
                       { prodName: "AC", price: "50000", vara: "5years" }];

    $scope.mybg = "#DC143C";
    $scope.textcolor = "#fff";

    $scope.changetextboxstyles = function () {
        $scope.mystyles = "#DC143C";
    }
});

myApp.controller("ContactCtrl", function ($scope) {
    $scope.myvalue = true;
    $scope.hideaddr = function () {
        $scope.myvalue = !$scope.myvalue;
    }

    $scope.mylink = "http://www.amensys.com";
    $scope.prodlink = "temps/products.html";
    $scope.servlink = "temps/services.html";
});